<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Encryptie Opdracht</title>
</head>
<body>
<form action="/Encryptie" method="POST">
    <?php echo method_field('PUT'); ?>
    <?php echo csrf_field(); ?>
    <?php if($hash != null): ?>
        <input type="hidden" value="<?php echo e($hash); ?>">
    <?php endif; ?>
    <button type="submit">Controleren</button>
</form>

</body>
</html>
<?php /**PATH C:\School\Leerjaar 2\SDLC 2\SDLC2Week5EncryptieLaravel\resources\views/controleer.blade.php ENDPATH**/ ?>