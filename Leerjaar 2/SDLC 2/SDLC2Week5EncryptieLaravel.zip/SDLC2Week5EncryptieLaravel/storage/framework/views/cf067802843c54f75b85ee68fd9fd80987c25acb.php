<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Home</title>
</head>
<body>
<h1>SDLC Applicatie</h1>
<h4>Wachtwoord</h4>
<form action="/" method="POST">
    <?php echo method_field('PUT'); ?>
    <?php echo csrf_field(); ?>
    <input name="passwordCheck" required><br>
    <button type="submit">Controleer wachtwoord</button>
</form>
<p><?php echo e($hash); ?></p>
</body>
</html>
<?php /**PATH C:\School\Leerjaar 2\SDLC 2\SDLC2Week5EncryptieLaravel\resources\views/home2.blade.php ENDPATH**/ ?>