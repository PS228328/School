<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Encryptie Opdracht</title>
</head>
<body>
<h1>Encryptie</h1>
<h4>Wachtwoord</h4>
<form action="/Encryptie" method="POST">
    <?php echo csrf_field(); ?>
    <input name="wachtwoord"><br>
    <button type="submit">Veranderen</button>
</form>
<a href="/Encryptie/Check">Controleer</a>
</body>
</html>
<?php /**PATH C:\School\Leerjaar 2\SDLC 2\SDLC2Week5EncryptieLaravel\resources\views/encryptie.blade.php ENDPATH**/ ?>