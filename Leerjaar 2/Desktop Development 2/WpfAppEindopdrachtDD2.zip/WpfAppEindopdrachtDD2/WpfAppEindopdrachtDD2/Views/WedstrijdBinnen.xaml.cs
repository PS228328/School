﻿using ConsoleAppEindopdrachtDD2;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfAppEindopdrachtDD2.Views
{
    /// <summary>
    /// Interaction logic for WedstrijdBinnen.xaml
    /// </summary>
    public partial class WedstrijdBinnen : Window
    {
        #region Properties
        private Binnenwedstrijd? binnenwedstrijd;
        public Binnenwedstrijd? Binnenwedstrijd
        {
            get { return binnenwedstrijd; }
            set { binnenwedstrijd = value; }
        }
        #endregion
        public WedstrijdBinnen()
        {
            InitializeComponent();
            DataContext = this;
        }
        protected override void OnClosing(CancelEventArgs e)
        {
            base.OnClosing(e);
            new MainWindow().Show();
        }
    }
}
