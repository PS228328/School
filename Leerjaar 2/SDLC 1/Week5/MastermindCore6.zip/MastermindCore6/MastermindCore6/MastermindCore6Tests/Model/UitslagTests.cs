﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using MastermindCore6.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MastermindCore6.Model.Tests
{
    [TestClass()]
    public class UitslagTests
    {
        [TestMethod()]
        public void UitslagTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void ToStringTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void UitslagTest1()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void ToStringTest1()
        {
            Assert.Fail();
        }
    }
}