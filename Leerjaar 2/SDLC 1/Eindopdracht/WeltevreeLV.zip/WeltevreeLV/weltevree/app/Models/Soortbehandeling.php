<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

abstract class Soortbehandeling extends Model
{
    const Parasietbehandeling = 1;
    const Inenten = 2;
    const Chippen = 3;
}
