<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Hond extends Model
{
    public string $chipId;
    public string $naam;
    private DateTime $geboortedatum;
    private string $ras;
    public function GetGeboortedatum() : DateTime {
        return $this->geboortedatum;
    }
    public function GetRas() : string {
        return $this->ras;
    }
    public function __construct(DateTime $geboortedatum, string $ras) {
        $this->geboortedatum = $geboortedatum;
        $this->ras = $ras;
    }
}
