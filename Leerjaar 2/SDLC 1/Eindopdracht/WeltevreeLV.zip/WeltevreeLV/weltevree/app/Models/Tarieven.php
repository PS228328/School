<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Tarieven extends Model
{
    public static float $dagprijsHond = 13.0;
    public static float $dagprijsKat = 7.0;
    public static float $administratiekosten = 5.0;
    public static float $parasietbehandeling = 5.0;
    public static float $inenting = 25;
    public static float $chippen = 15;
}
