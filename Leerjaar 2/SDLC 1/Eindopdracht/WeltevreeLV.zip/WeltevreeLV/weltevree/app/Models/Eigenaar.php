<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Eigenaar extends Model
{
    private string $naam;
    public string $adres;
    public string $telefoon;
    public string $bankrekening;
    public function GetNaam() : string {
        return $this->naam;
    }
    public function __construct(string $naam) {
        $this->naam = naam;
    }
}
