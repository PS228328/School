<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class VerblijfKat extends Model
{
    private DateTime $van;
    private DateTime $tot;
    private float $administratiekosten = 0.0;
    private float $behandelingskosten = 0.0;
    public bool $Betaald = false;
    public function GetVan() : DateTime {return $this->van;}
    public function GetTot() : DateTime {return $this->tot;}
    public function GetAdministratiekosten() : float {return $this->administratiekosten;}
    public function GetBehandelingskosten() : float {return $this->behandelingskosten;}
    private Eigenaar $eigenaar;
    private Kat $kat;
    public function __construct(Eigenaar $eigenaar, Kat $kat, DateTime $van, DateTime $tot) {
        $this->eigenaar = $eigenaar;
        $this->kat = $kat;
        $this->van = $van;
        $this->tot = $tot;
    }
    public function Verlengen (DateTime $tot) : void {
        $this->tot = $tot;
        $this->administratiekosten += Tarieven::administratiekosten;
    }
    public function Annuleren() : void {
        $this->tot = DateTime.Now;
        if ($this->van > $this->tot) $this->tot = $this->van;
        $this->administratiekosten += Tarieven::administratiekosten;
    }
    public function Behandelen (SoortBehandeling $soort) : void {
        switch ($soort)
        {
            case SoortBehandeling::Parasietbehandeling: $this->behandelingskosten += Tarieven::Parasietbehandeling; break;
            case SoortBehandeling::Inenten: $this->behandelingskosten += Tarieven::Inenting; break;
            case SoortBehandeling.Chippen: $this->behandelingskosten += Tarieven::Chippen; break;
        }
    }
    public function TotaalPrijs () : float {
        $verblijfkosten = $this->van->diff($this->tot)->format('%R%a') * Tarieven::DagprijsKat;
        return $verblijfkosten + $this->administratiekosten + $this->behandelingskosten;
    }
}
