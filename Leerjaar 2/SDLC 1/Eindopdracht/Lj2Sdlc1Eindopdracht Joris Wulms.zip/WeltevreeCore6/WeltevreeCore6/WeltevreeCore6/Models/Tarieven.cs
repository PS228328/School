﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeltevreeCore6.Models
{
    public static class Tarieven
    {
        public static double DagprijsHond = 13;
        public static double DagprijsKat = 7;
        public static double DagprijsKonijn = 5;
        public static double Administratiekosten = 5;
        public static double Parasietbehandeling = 5;
        public static double Inenting = 25;
        public static double Chippen = 15;
        public static double Uitlaatservice = 4;
    }
}
