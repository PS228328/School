﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfAppps228328Oefentoets
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        int endValue;
       
        

        private void btIf_Click(object sender, RoutedEventArgs e)
        {
            if (Joris.Text == "Optie 1")
                MessageBox.Show("Optie 1 is ingevoerd");

            else if (Joris.Text == "Optie 2")
                MessageBox.Show("Optie 2 is ingevoerd");

            else
                MessageBox.Show("Zowel optie 1 als optie 2 zijn niet ingegeven");
        }

        private void btWhile_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                endValue = int.Parse(Joris2.Text);
                Joris2.Text = endValue.ToString();

                MessageBoxResult myResult = MessageBox.Show("The counter is now " + endValue + " do you want to continue?", "Titel", MessageBoxButton.YesNo, MessageBoxImage.Warning);
                if (myResult == MessageBoxResult.No)
                {
                    return;
                }
                while (myResult == MessageBoxResult.Yes)
                {
                    endValue++;
                    Joris2.Text = endValue.ToString();
                    MessageBoxResult myTest = MessageBox.Show("The counter is now " + endValue + " do you want to continue?", "Titel", MessageBoxButton.YesNo, MessageBoxImage.Warning);
                    if (myTest == MessageBoxResult.No)
                    {
                        return;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Please fill in a number");
            }
            

        }

        private void btIfAndWhile_Click(object sender, RoutedEventArgs e)
        {
            
            MessageBoxResult myBox = MessageBox.Show("Do you want to start?", "Titel", MessageBoxButton.YesNoCancel);
            if (myBox == MessageBoxResult.Yes && Joris.Text == "Optie 1") 
            {
                MessageBox.Show("Optie 1 is getyped en je hebt op Yes geklikt, nice, de waarde van counter is nu 0 tot zodadelijk");
            }
            else if (myBox == MessageBoxResult.Yes && Joris.Text != "Optie 1") 
            {
                MessageBox.Show("Je hebt op yes geklikt, nice, de waarde van counter is nu 1 tot zodadelijk");
            }

            else if (myBox == MessageBoxResult.No) 
            {
                MessageBox.Show("Je hebt op No geklikt, nice, de waarde van counter is nu 2 tot zodadelijk");
            }
            else if (myBox == MessageBoxResult.Cancel)
            {
                MessageBox.Show("Je hebt op Cancel geklikt, doei. Oh ja, de counter is 3");
            }
                    
 
        }
        
    }
}
