﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfAppPractiseIfStatement
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private string ValueCombobox1 = null;
        private string ValueCombobox2 = null;
        private string ValueCombobox3 = null;
        private string[] _arrayGerechten = {/* optie 0 */ "Kunnen we in ieder geval een broodje kaas eten", 
            /* optie 1 */ "We kunnen een broodje kaas eten of een tosti maken", 
            /* optie 2 */ "We kunnen pannenkoeken bakken", 
            /* optie 3 */ "Niets te vreten" };
        public MainWindow()
        {
            InitializeComponent();
            //Hier kunt je de method selectElementComboBox() aanroepen zodat er een element wordt geselecteerd

        }

        private void btStart_Click(object sender, RoutedEventArgs e)
        {        
            watKunnenWeEten();
            MessageBox.Show("De waarde die in ComboBox 1 is geselecteerd is: " + ValueCombobox1 + "\n" + " ComboBox 2 is: " + ValueCombobox2 + "\n" + " en ComboBox 3 is: " + ValueCombobox3);
        }

        private void watKunnenWeEten()
        {


        }

        private void selectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //watKunnenWeEten();
        }

        private void selectElementComboBox()
        {
            cbOne.SelectedIndex = 0;
            cbTwo.SelectedIndex = 0;
            cbThree.SelectedIndex = 0;
        }
    }
}
