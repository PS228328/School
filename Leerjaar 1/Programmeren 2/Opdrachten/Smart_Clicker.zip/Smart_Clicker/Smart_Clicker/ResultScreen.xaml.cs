﻿using System.Windows;

namespace Smart_Clicker
{
    /// <summary>
    /// Interaction logic for ResultScreen.xaml
    /// </summary>
    public partial class ResultScreen : Window
    {
        public ResultScreen(string results)
        {
            InitializeComponent();
            // Vul de textbox txtResult met de string results.
        }
    }
}
