﻿using System;
using System.Windows;
using System.Windows.Threading;

namespace Smart_Clicker
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class SmartClicker : Window
    {
        int score = 0;
        DispatcherTimer schoolTimer = new DispatcherTimer();
        DispatcherTimer universityTimer = new DispatcherTimer();
        DispatcherTimer jobTimer = new DispatcherTimer();

        double multiplier = 1.0;

        int amountOfSchools = 0;
        int amountOfUniversities = 0;
        int amountOfJobs = 0;

        int pointsPerSchool = 5;
        int pointsPerUniversity = 20;
        int pointsPerJob = 50;

        int costSchool = 25;
        int costUniversity = 200;
        int costJob = 500;

        double schoolInterval = 1000;
        double universityInterval = 5000;
        double jobInterval = 10000;

        int costSchoolUpgrade = 250;
        int costUniversityUpgrade = 2000;
        int costJobUpgrade = 5000;

        int schoolUpgradeAmount = 0;
        int universityUpgradeAmount = 0;
        int jobUpgradeAmount = 0;

        private Random rand = new Random();

        public SmartClicker()
        {
            InitializeComponent();
            // Zet de Intervals van alle drie de timers (Milliseconden)
            // Gebruik per timer de bijbehorende variabelen (schoolTimer -> schoolInterval)

            // Koppel de Tick functies aan de bijbehorende timer

            // Start alle drie de timers
        }

        private void SchoolTimer_Tick(object sender, EventArgs e)
        {
            // Verhoog de score met de hoeveelheid schools keer pointsPerSchool
            // Update de label lblScoreTotal met de nieuwe score
        }
        private void UniversityTimer_Tick(object sender, EventArgs e)
        {
            // Zie SchoolTimer_Tick maar dan met de variabelen voor University
        }

        private void JobTimer_Tick(object sender, EventArgs e)
        {
            // Zie SchoolTimer_Tick maar dan met de variabelen voor Job
        }

        private void btnBrain_Click(object sender, RoutedEventArgs e)
        {
            // Verhoog de score met 1.
            // Update de label lblScoreTotal met de nieuwe score



            /**
             * Extra Opdracht Multiplier
             * Maak een variabele multiplierChance met een random getal tussen de 0 en 26
             * Als die variabele gelijk is aan 25 (1 op de 25 kans dus) verhoog je de multiplier
             * met één. Update ook de lblMultiplier met de nieuwe multiplier.
             * 
             * Zorg dat de score per klik niet wordt verhoogd met 1, maar met 1 keer de multiplier.
             */
        }

        private void btnSchool_Click(object sender, RoutedEventArgs e)
        {
            // Als de score hoger is dan de kosten voor een school trek de kosten van je score af.
            // Vermenigvuldig de kosten voor een school met 1.1 voor de volgende keer.
            // Update zowel de lblScoreTotal en lblCostOfSchools met de nieuwe waarden.
            // Verhoog de hoeveelheid schools met 1.
            // Update ook de lblAmountOfSchools met de nieuwe waarde.
        }

        private void btnUniversity_Click(object sender, RoutedEventArgs e)
        {
            // Zie btnSchool_Click maar dan met de variabelen voor universities
        }

        private void btnJob_Click(object sender, RoutedEventArgs e)
        {
            // Zie btnSchool_Click maar dan met de variabelen voor jobs
        }

        private void btnUpgrades_Click(object sender, RoutedEventArgs e)
        {
            // Als de upgrades StackPanel collapsed is, maak hem dan zichtbaar.
            // Anders, collapse hem.
        }

        private void btnBetterSchools_Click(object sender, RoutedEventArgs e)
        {
            // Als de score hoger is dan de kosten voor een school upgrade EN de hoeveelheid school upgrades kleiner is dan tien
            // Verhoog de hoeveelheid school upgrades
            // Haal de kosten van de score af
            // Vermenigvuldig de kosten voor een school upgrade met 1.2 voor de volgende keer.
            // Update de content van btnBetterSchools met de nieuwe kosten
            // Vermenigvuldig de interval voor schools met 0.8
            // Zet de nieuwe interval op de timer.

            // Als de hoeveelheid upgrades 10 is, verander dan de tekst van btnBetterSchools naar "Maximum school upgrades"
            // Maak in dit geval btnBetterSchools ook disabled. Zodat er niet meer op geklikt kan worden.
        }

        private void btnBetterUniversities_Click(object sender, RoutedEventArgs e)
        {
            // Zie btnBetterSchools_Click maar dan met variabelen voor universities
        }

        private void btnBetterJobs_Click(object sender, RoutedEventArgs e)
        {
            // Zie btnBetterSchools_Click maar dan met variabelen voor jobs
        }

        private void btnResult_Click(object sender, RoutedEventArgs e)
        {

            // Maak één string waarin je de speldata verwerkt.
            // Maak een resultscreen en geef je string hieraan mee.
            // Toon het resultscreen in een dialoog.
        }
    }
}
