﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Outrun
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        const int LEFT = 0;
        const int RIGHT = 1;

        private DispatcherTimer gameTimer;
        private DispatcherTimer movementTimer;
        private List<Rectangle> obstacles = new List<Rectangle>();
        private Random r = new Random();
        private int direction = LEFT;
        private int elapsedMiliseconds = 0;
        private int elapsedSeconds = 0;

        public MainWindow()
        {
            InitializeComponent();

            gameTimer = new DispatcherTimer();
            movementTimer = new DispatcherTimer();

            gameTimer.Tick += GameTimerTick;
            gameTimer.Interval = TimeSpan.FromMilliseconds(5);

            movementTimer.Tick += MovementTimerTick;
            movementTimer.Interval = TimeSpan.FromMilliseconds(10);

            this.KeyDown += KeyDownHandle;
            this.KeyUp += KeyUpHandle;

            RunGame();
        }

        private void KeyUpHandle(object sender, KeyEventArgs e)
        {
            movementTimer.Stop();
        }

        private void KeyDownHandle(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Left)
            {
                direction = LEFT;
            }
            else if (e.Key == Key.Right)
            {
                direction = RIGHT;
            }
            movementTimer.Start();
        }

        private void MovementTimerTick(object sender, EventArgs e)
        {
            if (direction == LEFT && car.Margin.Left > -gameGrid.Width)
            {
                car.Margin = new Thickness(car.Margin.Left - 5, gameGrid.Height - car.Height, 0, 0);
            }
            else if (direction == RIGHT && car.Margin.Left < (gameGrid.Width - car.ActualWidth))
            {
                car.Margin = new Thickness(car.Margin.Left + 5, gameGrid.Height - car.Height, 0, 0);
            }
        }

        private void GameTimerTick(object sender, EventArgs e)
        {
            elapsedMiliseconds += gameTimer.Interval.Milliseconds;
            elapsedSeconds = Convert.ToInt32(Math.Floor(Convert.ToDecimal(elapsedMiliseconds / 1000)));
            secondTimer.Text = elapsedSeconds.ToString();

            SpawnNewObstacles(); 
            MoveObstacles();
            CalculateHitBoxes();
        }

        private void SpawnNewObstacles()
        {
            int spawn = r.Next(0, 5);
            if (spawn == 4 && obstacles.Count < 30)
            {
                int position = r.Next(-Convert.ToInt32(gameGrid.Width), Convert.ToInt32(gameGrid.Width)-49);
                Rectangle rect = new Rectangle();
                rect.Width = 50;
                rect.Height = 50;
                Brush brush = new SolidColorBrush(
                    Color.FromRgb(
                        (byte)r.Next(0, 256), 
                        (byte)r.Next(0, 256), 
                        (byte)r.Next(0, 256)
                        )
                    );

                rect.Fill = brush;
                rect.Stroke = Brushes.White;

                gameGrid.Children.Add(rect);
                rect.Margin = new Thickness(position, -gameGrid.Height, 0, 0);
                obstacles.Add(rect);
            }
        }
            

        private void CalculateHitBoxes()
        {
            ObservableCollection<Rectangle> rectangles = new ObservableCollection<Rectangle>(obstacles);
            double carLeft = car.Margin.Left;
            double carTop = car.Margin.Top;
            foreach(Rectangle obstacle in rectangles)
            {
                double obstacleLeft = obstacle.Margin.Left;
                double obstacleTop = obstacle.Margin.Top;
                if (obstacleTop >= carTop && obstacleTop <= (carTop + car.ActualHeight))
                {
                    if (obstacleLeft >= carLeft && obstacleLeft <= (carLeft + car.ActualWidth))
                    {
                        movementTimer.Stop();
                        gameTimer.Stop();
                        MessageBoxResult result = MessageBox.Show(
                            "game over, you survived for " + elapsedSeconds + " seconds, would you like to try again?", 
                            "gameOver", 
                            MessageBoxButton.YesNo
                            );
                        if(result == MessageBoxResult.No)
                        {
                            Application.Current.Shutdown();
                        }

                        RunGame();
                    }
                }
            }
        }

        private void MoveObstacles()
        {
            ObservableCollection<Rectangle> rectangles = new ObservableCollection<Rectangle>(obstacles);
            foreach(Rectangle obstacle in rectangles)
            {
                obstacle.Margin = new Thickness(obstacle.Margin.Left, obstacle.Margin.Top + 5, 0, 0);
                if(obstacle.Margin.Top > gameGrid.Height)
                {
                   obstacles.Remove(obstacle);
                }
            }
        }

        private void RunGame()
        {
            elapsedMiliseconds = 0;
            elapsedSeconds = 0;
            secondTimer.Text = "0";

            if(gameGrid.Children.Count > 2) 
            {
                gameGrid.Children.RemoveRange(2, gameGrid.Children.Count);
                obstacles.Clear();
            }

            gameTimer.Start();
            double xpos = (MainWin.Width - car.ActualWidth) / 2;
            car.Margin = new Thickness(xpos, gameGrid.Height - car.Height, 0, 0);
        }
    }
}
